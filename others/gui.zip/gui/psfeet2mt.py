from Tkinter import *
from ttk import *


class Application(object):
    def __init__(self):
        self.root = Tk()
        self.root.title('Feet to Meter')
        self.feet = StringVar()
        self.meter = StringVar()
        self.mainframe = Frame(self.root, padding="3 3 12 12")
        self.__draw_app()

    def __compute(self):
        try:
            feet = float(self.feet.get())
            meter = (0.3408 * feet * 10000.0 + 0.5) / 10000.0
            self.meter.set("{:.5f}".format(meter))
        except ValueError:
            self.meter.set('Err...')

    def __draw_app(self):
        # set property to the frame
        self.mainframe.grid(row=0, column=0, sticky=(N, W, E, S))

        feet_entry = Entry(self.mainframe, width=7, textvariable=self.feet)
        feet_entry.grid(row=1, column=2, sticky=(W, E))

        feet_label = Label(self.mainframe, text='Feet')
        feet_label.grid(row=1, column=3, sticky=(W, E))

        equal_label = Label(self.mainframe, text='is equivalent to')
        equal_label.grid(row=2, column=1, sticky=E)

        Label(self.mainframe, textvariable=self.meter).grid(row=2, column=2, sticky=(W, E))

        meters_caption = Label(self.mainframe, text='Meters')
        meters_caption.grid(row=2, column=3, sticky=(W, E))

        Button(self.mainframe, text='Calculate', command=self.__compute).grid(row=3, column=3, sticky=(W, E))

        for child in self.mainframe.winfo_children():
            child.grid_configure(padx=5, pady=5)

        self.root.mainloop()

if __name__ == '__main__':
    Application()

