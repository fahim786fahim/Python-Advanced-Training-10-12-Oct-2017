from Tkinter import *


def button_action(*args):
    print 'am clicked'


root = Tk()
# w = Label(root, text='Hello Tkinter')
w = Button(root, text='Hello....', command=button_action)
w.pack()
root.mainloop()